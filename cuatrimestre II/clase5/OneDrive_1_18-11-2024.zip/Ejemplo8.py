#   Cuadros de mensajes

from tkinter import messagebox
messagebox.showerror(message="Todos aprobados",title="Felicidades")