#   Crear un archivo llamado ejemplo1.txt

from io import open

f = open(r"C:\Users\Sistemas\Desktop\18-11\ejemplo1.txt","w")