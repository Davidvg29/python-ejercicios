#   Diagrama de lineas

import matplotlib.pyplot as plt
fix, ax = plt.subplots()
ax.plot([1,2,3,4,5,6,7],[1,12,30,24,65,67,37])
plt.savefig("Diagra_de_lineas.png")
plt.show