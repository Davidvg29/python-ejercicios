#   Dado dos numeros enteros sumarlos y presenta la suma en pantalla
#   Sin funciones

numero1 = int(input("Ingrese el primer numero entero: "))
numero2 = int(input("Ingrese el segundo numero entero: "))

resultado = numero1 + numero2

print(f"El valor de la suma de {numero1} y {numero2} es igual a {resultado}")
#print(f"El valor de la suma de {numero1} y {numero2} es igual a {numero1 + numero2}")